#import "MBProgressHUD.h"

@interface MBProgressHUD (Extension)

+ (void)show:(NSString *)text icon:(NSString *)icon view:(UIView *)view hideAfterDelay:(CGFloat)afterDelay;
+ (void)showError:(NSString *)error toView:(UIView *)view hideAfterDelay:(CGFloat)afterDelay;
+ (void)showSuccess:(NSString *)success toView:(UIView *)view hideAfterDelay:(CGFloat)afterDelay;

+ (MBProgressHUD *)showMessage:(NSString *)message toView:(UIView *)view;

+ (void)showSuccess:(NSString *)success;
+ (void)showError:(NSString *)error;
+ (void)showSuccess:(NSString *)success hideAfterDelay:(CGFloat)afterDelay;
+ (void)showError:(NSString *)error hideAfterDelay:(CGFloat)afterDelay;

+ (MBProgressHUD *)showMessage:(NSString *)message;


+ (void)hideHudWithMessageSuccess:(NSString *)message;
+ (void)hideHudWithMessageError:(NSString *)message;
+ (void)hideHUDForView:(UIView *)view;
+ (void)hideHUD;

@end
