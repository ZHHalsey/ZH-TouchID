#import "MBProgressHUD+Extension.h"

#define HUDDefaultAfterDelay 2.0

@implementation MBProgressHUD (Extension)

+ (void)show:(NSString *)text icon:(NSString *)icon view:(UIView *)view hideAfterDelay:(CGFloat)afterDelay{
    if (view == nil) {
        view = [[UIApplication sharedApplication].windows lastObject];
    }
    // 快速显示一个提示信息
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.labelText = text;
    // 设置图片
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"MBProgressHUD.bundle/%@", icon]]];
    // 再设置模式
    hud.mode = MBProgressHUDModeCustomView;
    
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    
    // afterDelay秒之后再消失
    [hud hide:YES afterDelay:afterDelay];
}

+ (void)showError:(NSString *)error toView:(UIView *)view hideAfterDelay:(CGFloat)afterDelay{
    [self show:error icon:@"error.png" view:view hideAfterDelay:afterDelay];
}

+ (void)showSuccess:(NSString *)success toView:(UIView *)view hideAfterDelay:(CGFloat)afterDelay{
    [self show:success icon:@"success.png" view:view hideAfterDelay:afterDelay];
}

+ (MBProgressHUD *)showMessage:(NSString *)message toView:(UIView *)view {
    if (view == nil) {
        view = [[UIApplication sharedApplication].windows lastObject];
    }
    // 快速显示一个提示信息
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.labelText = message;
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    // YES代表需要蒙版效果
    hud.dimBackground = YES;
    return hud;
}

+ (void)showSuccess:(NSString *)success{
    [self showSuccess:success toView:nil hideAfterDelay:HUDDefaultAfterDelay];
}

+ (void)showSuccess:(NSString *)success hideAfterDelay:(CGFloat)afterDelay{
    [self showSuccess:success toView:nil hideAfterDelay:afterDelay];
}

+ (void)showError:(NSString *)error{
    [self showError:error toView:nil hideAfterDelay:HUDDefaultAfterDelay];
}

+ (void)showError:(NSString *)error hideAfterDelay:(CGFloat)afterDelay{
    [self showError:error toView:nil hideAfterDelay:afterDelay];
}

+ (MBProgressHUD *)showMessage:(NSString *)message{
    return [self showMessage:message toView:nil];
}

+ (void)hideHUDForView:(UIView *)view{
    [self hideHUDForView:view animated:YES];
}

+ (void)hideHUD{
    [self hideHUDForView:nil];
}

+(void)hideHudWithMessageSuccess:(NSString *)message{
    [self hideHUDForView:nil];
    [self showSuccess:message hideAfterDelay:1.0];
}

+(void)hideHudWithMessageError:(NSString *)message{
    [self hideHUDForView:nil];
    [self showError:message hideAfterDelay:1.0];
}

@end
