//
//  ViewController.m
//  指纹开发
//
//  Created by ZZZZZ on 16/7/26.
//  Copyright © 2016年 张豪. All rights reserved.
//

#import "ViewController.h"
#import <LocalAuthentication/LocalAuthentication.h>
#import "MBProgressHUD.h"
#import "MBProgressHUD+Extension.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    UIButton *btn = [UIButton buttonWithType:0];
    btn.frame = CGRectMake(10, 50, self.view.bounds.size.width - 20, 50);
    btn.backgroundColor = [UIColor grayColor];
    [btn setTitle:@"点击我开始验证" forState:0];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];


}

- (void)btnClick{
    
    NSLog(@"点击了验证指纹按钮");
    /*
     依赖框架LocalAuthentication.framework
     使用类：LAContext 指纹验证操作对象
     */
    
    // 初始化上下文
    LAContext *context = [[LAContext alloc]init];
    // 错误对象
    NSError *error = nil;
    
    // 首先使用canEvaluatePolicy判断设备是否支持Touch ID
    if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
        NSLog(@"您的设备Touch ID可用");
        [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"需要验证您的指纹来确认您的信息" reply:^(BOOL success, NSError * _Nullable error) {
            if (success) {
                NSLog(@"指纹验证成功");
                // 验证成功, 主线程处理UI
//                [MBProgressHUD hideHudWithMessageSuccess:@"指纹验证成功"]; // 这里不能用这个三方库, 会导致程序运行的很慢
            }
            else{
                
                NSLog(@"111%@", error.localizedDescription);
                switch (error.code) {
                    case LAErrorSystemCancel:
                    {
                        NSLog(@"系统取消验证Touch ID");
                        // 切换到其他App, 系统取消验证Touch ID
                        break;
                    }
                    case LAErrorUserCancel:{
                        NSLog(@"用户取消验证Touch ID");
                        // 用户取消验证Touch ID;
                        break;
                    }
                    case LAErrorUserFallback:
                    {
                        NSLog(@"用户选择输入密码");
                        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                            //用户选择输入密码，切换主线程处理
                        }];
                        break;
                    }
                    default:
                    {
                        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                            //其他情况，切换主线程处理
                        }];
                        break;
                    }
                }
            }
        }];
    }else{
        NSLog(@"您的设别暂还不支持Touch ID");
        // 不支持指纹识别, LOG出错误详情
        switch (error.code) {
            case LAErrorTouchIDNotEnrolled:
            {
                NSLog(@"TouchID还没有录入");
                break;
            }
            case LAErrorPasscodeNotSet:
            {
                NSLog(@"你还没有设置密码");
                break;
            }
            default:
            {
                NSLog(@"TouchID不可用");
                break;
            }
        }
        NSLog(@"222%@",error.localizedDescription);
    }
}




@end
