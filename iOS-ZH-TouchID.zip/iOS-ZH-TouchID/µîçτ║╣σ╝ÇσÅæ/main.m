//
//  main.m
//  指纹开发
//
//  Created by ZZZZZ on 16/7/26.
//  Copyright © 2016年 张豪. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
